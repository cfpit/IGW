import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || ''

// ==========================================
// SERVICIOS CON AXIOS
// ==========================================
export const personaServiceAxios = {
  async getPersonas() {
    const response = await axios.get(`${BASE_URL}/personas/traer`)
    return response.data
  },

  async crearPersona(persona) {
    const response = await axios.post(`${BASE_URL}/personas/crear`, persona)
    return response.data
  },

  async eliminarPersona(id) {
    const response = await axios.delete(`${BASE_URL}/personas/borrar/${id}`)
    return response.data
  },

  async editarPersona(idOriginal, { id, nombre, edad }) {
    const response = await axios.put(
      `${BASE_URL}/personas/editar/${idOriginal}`,
      null,
      {
        params: { id, nombre, edad },
      }
    )
    return response.data
  },
}

// ==========================================
// SERVICIOS CON FETCH NATIVO
// ==========================================
export const personaServiceFetch = {
  async getPersonas() {
    const response = await fetch(`${BASE_URL}/personas/traer`)
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.json()
  },

  async crearPersona(persona) {
    const response = await fetch(`${BASE_URL}/personas/crear`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(persona),
    })
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.text()
  },

  async eliminarPersona(id) {
    const response = await fetch(`${BASE_URL}/personas/borrar/${id}`, {
      method: 'DELETE',
    })
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.text()
  },

  async editarPersona(idOriginal, { id, nombre, edad }) {
    const params = new URLSearchParams({
      id: String(id),
      nombre,
      edad: String(edad),
    })
    const response = await fetch(
      `${BASE_URL}/personas/editar/${idOriginal}?${params.toString()}`,
      {
        method: 'PUT',
      }
    )
    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`)
    }
    return await response.json()
  },
}

