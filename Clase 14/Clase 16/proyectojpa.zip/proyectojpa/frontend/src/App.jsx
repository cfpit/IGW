import { useState, useEffect, useCallback } from 'react'
import { personaServiceAxios, personaServiceFetch } from './services/personaService'

function App() {
  const [personas, setPersonas] = useState([])
  const [nombre, setNombre] = useState('')
  const [edad, setEdad] = useState('')
  const [clienteHttp, setClienteHttp] = useState('axios') // 'axios' o 'fetch'
  const [modoEdicion, setModoEdicion] = useState(null)
  const [mensaje, setMensaje] = useState(null)
  const [cargando, setCargando] = useState(false)
  const [guardando, setGuardando] = useState(false)

  // Obtiene el servicio según el cliente seleccionado
  const obtenerServicio = useCallback(() => {
    return clienteHttp === 'axios' ? personaServiceAxios : personaServiceFetch
  }, [clienteHttp])

  // Cargar lista de personas (reutilizable tras crear/editar/eliminar)
  const recargarPersonas = useCallback(async () => {
    setCargando(true)
    try {
      const servicio = obtenerServicio()
      const datos = await servicio.getPersonas()
      setPersonas(Array.isArray(datos) ? datos : [])
    } catch (error) {
      console.error(`Error al traer personas (${clienteHttp}):`, error)
      setMensaje({
        tipo: 'danger',
        texto: `Error al traer personas usando ${clienteHttp.toUpperCase()}`,
      })
    } finally {
      setCargando(false)
    }
  }, [clienteHttp, obtenerServicio])

  // Efecto para sincronizar con la API al montar o cambiar el cliente HTTP
  useEffect(() => {
    let cancelado = false

    async function fetchData() {
      try {
        const servicio = clienteHttp === 'axios' ? personaServiceAxios : personaServiceFetch
        const datos = await servicio.getPersonas()
        if (!cancelado) {
          setPersonas(Array.isArray(datos) ? datos : [])
        }
      } catch (error) {
        if (!cancelado) {
          console.error(`Error al traer personas (${clienteHttp}):`, error)
          setMensaje({
            tipo: 'danger',
            texto: `Error al traer personas usando ${clienteHttp.toUpperCase()}`,
          })
        }
      }
    }

    fetchData()

    return () => {
      cancelado = true
    }
  }, [clienteHttp])

  // Guardar o Editar Persona
  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!nombre.trim() || !edad) {
      setMensaje({
        tipo: 'danger',
        texto: 'Por favor complete todos los campos.',
      })
      return
    }

    setGuardando(true)
    setMensaje(null)
    const servicio = obtenerServicio()

    try {
      if (modoEdicion) {
        await servicio.editarPersona(modoEdicion.id, {
          id: modoEdicion.id,
          nombre: nombre.trim(),
          edad: parseInt(edad, 10),
        })
        setMensaje({
          tipo: 'success',
          texto: `Persona actualizada con éxito (${clienteHttp.toUpperCase()})`,
        })
        cancelarEdicion()
      } else {
        await servicio.crearPersona({
          nombre: nombre.trim(),
          edad: parseInt(edad, 10),
        })
        setMensaje({
          tipo: 'success',
          texto: `Persona guardada con éxito (${clienteHttp.toUpperCase()})`,
        })
        setNombre('')
        setEdad('')
      }
      await recargarPersonas()
    } catch (error) {
      console.error(`Error al procesar persona (${clienteHttp}):`, error)
      setMensaje({
        tipo: 'danger',
        texto: `Error al ${modoEdicion ? 'editar' : 'guardar'} la persona con ${clienteHttp.toUpperCase()}`,
      })
    } finally {
      setGuardando(false)
    }
  }

  // Eliminar persona
  const handleEliminar = async (id) => {
    if (!window.confirm(`¿Seguro que deseas eliminar a la persona con ID ${id}?`)) {
      return
    }

    const servicio = obtenerServicio()
    try {
      await servicio.eliminarPersona(id)
      setMensaje({
        tipo: 'success',
        texto: `Persona eliminada con éxito (${clienteHttp.toUpperCase()})`,
      })
      if (modoEdicion?.id === id) {
        cancelarEdicion()
      }
      await recargarPersonas()
    } catch (error) {
      console.error(`Error al eliminar persona (${clienteHttp}):`, error)
      setMensaje({
        tipo: 'danger',
        texto: `Error al eliminar la persona con ${clienteHttp.toUpperCase()}`,
      })
    }
  }

  // Iniciar edición
  const handleIniciarEdicion = (persona) => {
    setModoEdicion(persona)
    setNombre(persona.nombre)
    setEdad(persona.edad)
    setMensaje(null)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  // Cancelar edición
  const cancelarEdicion = () => {
    setModoEdicion(null)
    setNombre('')
    setEdad('')
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 py-10 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Cabecera */}
        <header className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold rounded-full uppercase tracking-wider">
            Spring Boot + React 19 + Tailwind CSS
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Consumo de API Spring Boot
          </h1>
          <p className="text-slate-500 max-w-xl mx-auto text-sm sm:text-base">
            Frontend moderno impulsado por <strong>Vite</strong>, <strong>Tailwind CSS v4</strong> y <strong>pnpm</strong>.
          </p>

          {/* Selector de Cliente HTTP */}
          <div className="pt-2 flex justify-center items-center gap-3">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cliente HTTP:</span>
            <div className="inline-flex rounded-lg bg-slate-200/80 p-1 shadow-inner">
              <button
                type="button"
                onClick={() => setClienteHttp('axios')}
                className={`px-3.5 py-1 text-xs font-medium rounded-md transition-all ${
                  clienteHttp === 'axios'
                    ? 'bg-white text-blue-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Axios
              </button>
              <button
                type="button"
                onClick={() => setClienteHttp('fetch')}
                className={`px-3.5 py-1 text-xs font-medium rounded-md transition-all ${
                  clienteHttp === 'fetch'
                    ? 'bg-white text-blue-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Fetch API
              </button>
            </div>
          </div>
        </header>

        {/* Mensaje de alerta */}
        {mensaje && (
          <div
            className={`flex items-center justify-between p-4 rounded-xl border text-sm shadow-sm transition-all ${
              mensaje.tipo === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
            role="alert"
          >
            <div className="flex items-center gap-2">
              <span className="font-semibold">
                {mensaje.tipo === 'success' ? '✓ Éxito:' : '⚠ Atención:'}
              </span>
              <span>{mensaje.texto}</span>
            </div>
            <button
              type="button"
              onClick={() => setMensaje(null)}
              className="text-xs font-bold px-2 py-1 rounded hover:bg-black/5 transition"
              aria-label="Cerrar"
            >
              ✕
            </button>
          </div>
        )}

        {/* Formulario */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="border-b border-slate-100 bg-slate-50/50 px-6 py-4">
            <h2 className="text-lg font-semibold text-slate-800 text-center">
              {modoEdicion ? `Editar Persona (ID: ${modoEdicion.id})` : 'Crear Persona'}
            </h2>
          </div>

          <form id="formulario-persona" onSubmit={handleSubmit} className="p-6 space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="nombre" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Nombre
                </label>
                <input
                  type="text"
                  id="nombre"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  placeholder="Ej. Juan Pérez"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition"
                />
              </div>

              <div>
                <label htmlFor="edad" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Edad
                </label>
                <input
                  type="number"
                  id="edad"
                  value={edad}
                  onChange={(e) => setEdad(e.target.value)}
                  placeholder="Ej. 28"
                  min="1"
                  max="120"
                  required
                  className="w-full rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="submit"
                disabled={guardando}
                className="inline-flex items-center justify-center rounded-lg bg-blue-600 px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/30 disabled:opacity-50 transition cursor-pointer"
              >
                {guardando ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
                    </svg>
                    Procesando...
                  </span>
                ) : modoEdicion ? (
                  'Actualizar Persona'
                ) : (
                  'Guardar Persona'
                )}
              </button>

              {modoEdicion && (
                <button
                  type="button"
                  onClick={cancelarEdicion}
                  disabled={guardando}
                  className="rounded-lg border border-slate-300 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 transition cursor-pointer"
                >
                  Cancelar Edición
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Tabla de Personas */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="border-b border-slate-100 bg-slate-50/50 px-6 py-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-800">
              Tabla de Personas
            </h2>
            <button
              type="button"
              onClick={recargarPersonas}
              disabled={cargando}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-blue-600 bg-white border border-slate-200 hover:border-blue-300 px-3 py-1.5 rounded-lg transition shadow-xs cursor-pointer"
              title="Recargar tabla"
            >
              <span className={cargando ? 'animate-spin inline-block' : ''}>↻</span>
              {cargando ? 'Cargando...' : 'Recargar'}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm" id="tabla1">
              <thead className="bg-slate-50 text-slate-500 uppercase text-xs tracking-wider border-b border-slate-100">
                <tr>
                  <th scope="col" className="px-6 py-3.5 font-semibold text-center w-20">ID</th>
                  <th scope="col" className="px-6 py-3.5 font-semibold">Nombre</th>
                  <th scope="col" className="px-6 py-3.5 font-semibold text-center w-28">Edad</th>
                  <th scope="col" className="px-6 py-3.5 font-semibold text-center w-40">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {cargando && personas.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="text-center py-8 text-slate-400">
                      Cargando personas desde la API...
                    </td>
                  </tr>
                ) : personas.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="text-center py-8 text-slate-400">
                      No hay personas registradas en la base de datos.
                    </td>
                  </tr>
                ) : (
                  personas.map((persona) => (
                    <tr key={persona.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-6 py-4 font-mono font-medium text-slate-500 text-center">
                        {persona.id}
                      </td>
                      <td className="px-6 py-4 font-medium text-slate-900">
                        {persona.nombre}
                      </td>
                      <td className="px-6 py-4 text-center text-slate-600">
                        {persona.edad}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleIniciarEdicion(persona)}
                            className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition cursor-pointer"
                          >
                            Editar
                          </button>
                          <button
                            type="button"
                            onClick={() => handleEliminar(persona.id)}
                            className="px-2.5 py-1 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition cursor-pointer"
                          >
                            Borrar
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 text-xs text-slate-500 text-right">
            Total de registros: <span className="font-semibold text-slate-700">{personas.length}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
