# Guía Integral: Arquitectura Backend (Spring Boot) y Consumo Frontend (React + Vite + Tailwind CSS)

Este proyecto académico implementa un sistema cliente-servidor desacoplado para la gestión integral (CRUD) de la entidad `Persona`. El backend está desarrollado en **Spring Boot 3** con persistencia en **MySQL** mediante **Spring Data JPA/Hibernate**, mientras que el frontend está construido en **React 19**, estilizado con **Tailwind CSS v4** mediante su plugin nativo para **Vite**, y administrado con **pnpm**.

El objetivo central de este documento es explicar detalladamente **cómo funciona internamente el backend** y, fundamentalmente, **cómo el frontend en React consume cada uno de los endpoints de la API**, comparando las implementaciones con **Axios** y **Fetch API nativo**.

---

## 📐 1. Arquitectura General del Sistema

El flujo completo de información sigue una arquitectura en capas basada en el protocolo HTTP/REST:

```mermaid
flowchart TD
    subgraph Frontend["Frontend (React 19 + Vite + Tailwind CSS)"]
        UI["Interfaz de Usuario (App.jsx)"]
        State["Estado React (useState / useEffect)"]
        Service["Capa de Servicios (personaService.js)"]
        Clients["Cliente HTTP (Axios / Fetch)"]
        
        UI <--> State
        State --> Service
        Service --> Clients
    end

    subgraph Red["Capa de Red / Transporte"]
        HTTP["Peticiones HTTP (JSON / REST)"]
        Proxy["Vite Proxy (:5173) / Directo (:8080)"]
    end

    subgraph Backend["Backend (Spring Boot 3)"]
        Controller["PersonaController (@RestController)"]
        ServiceLayer["PersonaService (@Service)"]
        Repo["IPersonaRepository (JpaRepository)"]
        
        Controller --> ServiceLayer
        ServiceLayer --> Repo
    end

    subgraph Database["Persistencia"]
        MySQL[("Base de Datos MySQL")]
        Repo <--> MySQL
    end

    Clients --> Proxy
    Proxy --> HTTP
    HTTP --> Controller
```

---

## ⚙️ 2. Funcionamiento Detallado del Backend (Spring Boot)

El backend sigue el patrón arquitectónico estándar de Spring Boot dividido en cuatro capas esenciales:

### 2.1. Capa de Modelo / Entidad ([`Persona.java`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/src/main/java/ar/edu/centro8/desarrollo/proyectojpa/model/Persona.java))
Representa la tabla `persona` en la base de datos relacional MySQL:
* `@Entity`: Marca la clase como entidad JPA gestionada por Hibernate.
* `@Id` y `@GeneratedValue(strategy = GenerationType.SEQUENCE)`: Define la clave primaria autogenerada mediante una secuencia.
* **POJO Estándar (Java Puro):** Implementa constructores (vacío y con parámetros) y métodos getters/setters explícitos. Se prescinde de Lombok para garantizar **100% de compatibilidad nativa con Java 25**, evitando incompatibilidades con las estructuras internas del compilador `javac` (`com.sun.tools.javac.code.TypeTag :: UNKNOWN`).

### 2.2. Capa de Repositorio ([`IPersonaRepository.java`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/src/main/java/ar/edu/centro8/desarrollo/proyectojpa/repository/IPersonaRepository.java))
```java
@Repository
public interface IPersonaRepository extends JpaRepository<Persona, Long> {
}
```
Al heredar de `JpaRepository<Persona, Long>`, Spring Data JPA provee automáticamente en tiempo de ejecución las operaciones CRUD (`save`, `findAll`, `findById`, `deleteById`) sin requerir sentencias SQL manuales.

### 2.3. Capa de Servicio ([`PersonaService.java`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/src/main/java/ar/edu/centro8/desarrollo/proyectojpa/service/PersonaService.java))
Encapsula la lógica de negocio y desacopla el controlador del repositorio. Implementa [`IPersonaService`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/src/main/java/ar/edu/centro8/desarrollo/proyectojpa/service/IPersonaService.java):
* `getPersonas()`: Invoca `persoRepo.findAll()`.
* `savePersona(Persona)`: Invoca `persoRepo.save(perso)`.
* `deletePersona(Long id)`: Invoca `persoRepo.deleteById(id)`.
* `findPersona(Long id)`: Busca por ID retornando `persoRepo.findById(id).orElse(null)`.
* `editPersona(...)`: Busca la entidad original, actualiza sus campos `nombre` y `edad`, y persiste los cambios.

### 2.4. Capa de Controlador REST ([`PersonaController.java`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/src/main/java/ar/edu/centro8/desarrollo/proyectojpa/controller/PersonaController.java))
Expone los puntos de entrada HTTP:
* `@RestController`: Combina `@Controller` y `@ResponseBody`. Todas las respuestas retornadas se serializan directamente a formato JSON o texto plano en el cuerpo de la respuesta HTTP.
* `@CrossOrigin(origins = "*", methods = {GET, POST, PUT, DELETE})`: Configuración de CORS (*Cross-Origin Resource Sharing*) que permite recibir peticiones de cualquier origen, fundamental para que el servidor de desarrollo de Vite (`http://localhost:5173`) pueda comunicarse con Spring Boot (`http://localhost:8080`) sin bloqueos de seguridad del navegador.

#### Tabla de Endpoints Expuestos

| Método HTTP | Endpoint | Tipo Parámetro | Cuerpo / Parámetros | Tipo Retorno | Descripción |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `GET` | `/personas/traer` | Ninguno | Ninguno | `List<Persona>` (JSON) | Retorna el listado completo de personas. |
| `POST` | `/personas/crear` | `@RequestBody` | JSON: `{"nombre": "...", "edad": ...}` | `String` (Texto plano) | Da de alta una nueva persona. |
| `DELETE` | `/personas/borrar/{id}` | `@PathVariable` | ID en la URL (ej: `/personas/borrar/1`) | `String` (Texto plano) | Elimina a la persona por su ID. |
| `PUT` | `/personas/editar/{id_original}` | `@PathVariable` + `@RequestParam` | Path: `id_original`<br>Query: `?id=...&nombre=...&edad=...` | `Persona` (JSON) | Actualiza los datos de una persona existente. |

---

## 🌐 3. Funcionamiento Detallado del Frontend (React + Vite + Tailwind CSS)

El frontend está estructurado de manera modular para separar la interfaz gráfica, la gestión de estado y la comunicación con la API.

### 3.1. Arquitectura de Archivos en `frontend/`

```text
frontend/
├── src/
│   ├── services/
│   │   └── personaService.js       # Capa de consumo HTTP (Axios y Fetch nativo)
│   ├── App.jsx                     # Componente principal: estado, formulario y tabla
│   ├── index.css                   # Importación de Tailwind CSS (@import "tailwindcss";)
│   └── main.jsx                    # Punto de entrada de React 19 (createRoot)
├── index.html                      # Contenedor HTML raíz (<div id="root"></div>)
├── vite.config.js                  # Configuración de Tailwind v4, Proxy y OutDir hacia static/
├── package.json                    # Dependencias y scripts de ejecución
└── backup-vanilla-index.html       # Respaldo pedagógico del index.html JavaScript nativo
```

---

### 3.2. ¿Cómo se consume la API? ([`personaService.js`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/frontend/src/services/personaService.js))

Para facilitar el aprendizaje, el servicio cuenta con dos objetos exportados que implementan exactamente las mismas 4 operaciones del backend:
1. `personaServiceAxios`: implementado con la librería **Axios**.
2. `personaServiceFetch`: implementado con la **Fetch API** nativa de JavaScript.

#### Definición de la URL Base:
```javascript
const BASE_URL = import.meta.env.VITE_API_BASE_URL || '';
```
* **En desarrollo (`localhost:5173`):** Al dejar `BASE_URL = ''`, la petición se hace a la misma dirección de origen y el **Proxy de Vite** la redirige a `http://localhost:8080`.
* **En producción (`localhost:8080`):** Al servirse desde la carpeta `static/` de Spring Boot, las rutas relativas (`/personas/...`) pegan directamente al backend sin necesidad de configurar URLs fijas.

---

### 3.3. Comparativa Técnica: Axios vs Fetch en cada Operación

#### 1. Obtener listado de personas (`GET /personas/traer`)

* **Con Axios:**
  ```javascript
  async getPersonas() {
    const response = await axios.get(`${BASE_URL}/personas/traer`);
    return response.data; // Axios parsea automáticamente el JSON a un Array de objetos
  }
  ```
* **Con Fetch API:**
  ```javascript
  async getPersonas() {
    const response = await fetch(`${BASE_URL}/personas/traer`);
    if (!response.ok) { // Fetch NO arroja error en estados 4xx o 5xx; se debe validar manualmente
      throw new Error(`Error HTTP: ${response.status}`);
    }
    return await response.json(); // Se debe invocar .json() explícitamente para leer y parsear el body
  }
  ```

#### 2. Registrar una nueva persona (`POST /personas/crear`)

El backend espera una cabecera `Content-Type: application/json` y un cuerpo JSON deserializable en la clase Java `Persona`.

* **Con Axios:**
  ```javascript
  async crearPersona(persona) {
    // Axios detecta el objeto JavaScript, lo serializa automáticamente a JSON y agrega el header
    const response = await axios.post(`${BASE_URL}/personas/crear`, persona);
    return response.data; // Devuelve el mensaje: "La persona fue creada correctamente"
  }
  ```
* **Con Fetch API:**
  ```javascript
  async crearPersona(persona) {
    const response = await fetch(`${BASE_URL}/personas/crear`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json', // Obligatorio indicar el formato al backend
      },
      body: JSON.stringify(persona), // Se debe serializar el objeto JS a cadena JSON manualmente
    });
    if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
    return await response.text(); // El backend retorna un String plano, no un objeto JSON
  }
  ```

#### 3. Eliminar una persona (`DELETE /personas/borrar/{id}`)

El parámetro viaja embebido directamente en la ruta (PathVariable).

* **Con Axios:**
  ```javascript
  async eliminarPersona(id) {
    const response = await axios.delete(`${BASE_URL}/personas/borrar/${id}`);
    return response.data;
  }
  ```
* **Con Fetch API:**
  ```javascript
  async eliminarPersona(id) {
    const response = await fetch(`${BASE_URL}/personas/borrar/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
    return await response.text();
  }
  ```

#### 4. Actualizar datos (`PUT /personas/editar/{id_original}`)

El controlador recibe el ID original en el path y los nuevos valores por Query Parameters (`?id=...&nombre=...&edad=...`).

* **Con Axios:**
  ```javascript
  async editarPersona(idOriginal, { id, nombre, edad }) {
    // El segundo argumento es el body (null); el tercero es la configuración con params
    const response = await axios.put(
      `${BASE_URL}/personas/editar/${idOriginal}`,
      null,
      { params: { id, nombre, edad } }
    );
    return response.data;
  }
  ```
* **Con Fetch API:**
  ```javascript
  async editarPersona(idOriginal, { id, nombre, edad }) {
    const params = new URLSearchParams({
      id: String(id),
      nombre,
      edad: String(edad),
    });
    const response = await fetch(
      `${BASE_URL}/personas/editar/${idOriginal}?${params.toString()}`,
      { method: 'PUT' }
    );
    if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
    return await response.json();
  }
  ```

---

### 3.4. Diagrama de Secuencia del Flujo Frontend - Backend

```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant React as React UI (App.jsx)
    participant State as Estado React (useState)
    participant Servicio as Servicio (Axios / Fetch)
    participant Spring as Spring Boot Controller (:8080)
    participant DB as MySQL

    Note over Usuario,DB: 1. Carga Inicial de Datos
    React->>Servicio: getPersonas()
    Servicio->>Spring: GET /personas/traer
    Spring->>DB: persoRepo.findAll()
    DB-->>Spring: Registros encontrados
    Spring-->>Servicio: 200 OK [ {id: 1, nombre: "Ana", edad: 25} ]
    Servicio-->>State: setPersonas(datos)
    State-->>React: Re-renderiza filas en la tabla

    Note over Usuario,DB: 2. Alta de Persona
    Usuario->>React: Completa Nombre y Edad, clic en "Guardar"
    React->>Servicio: crearPersona({ nombre, edad })
    Servicio->>Spring: POST /personas/crear (body: JSON)
    Spring->>DB: persoRepo.save(perso)
    DB-->>Spring: Registro persistido
    Spring-->>Servicio: 200 OK "La persona fue creada correctamente"
    Servicio-->>State: setMensaje("Éxito"), setNombre(""), setEdad("")
    React->>Servicio: recargarPersonas() (GET /personas/traer)
    Servicio-->>State: Actualiza lista con el nuevo registro
```

---

### 3.5. Gestión del Estado y Ciclo de Vida en [`App.jsx`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/frontend/src/App.jsx)

El componente principal administra la reactividad de la aplicación mediante Hooks:

* `useState`:
  * `personas`: Almacena el array de personas obtenido de la API para mapearlo en la tabla.
  * `nombre` y `edad`: Vinculados bidireccionalmente a los inputs del formulario (*Controlled Components*).
  * `clienteHttp`: Guarda la selección activa (`'axios'` o `'fetch'`), permitiendo al usuario probar ambos clientes desde la interfaz.
  * `modoEdicion`: Almacena el objeto `persona` que se está editando o `null` si se está creando una nueva persona.
  * `mensaje`: Objeto `{ tipo: 'success' | 'danger', texto: '...' }` que alimenta las alertas visuales con cierre interactivo.
  * `cargando` y `guardando`: Indicadores booleanos para deshabilitar botones y mostrar spinners durante las transiciones asíncronas.
* `useEffect`:
  * Se ejecuta al montar el componente y cada vez que cambia `clienteHttp`.
  * Implementa una bandera `cancelado` (*cleanup function*) para evitar condiciones de carrera (*race conditions*) si el usuario conmuta rápidamente entre Axios y Fetch antes de que finalice la petición previa.
* `useCallback`:
  * Memoriza las funciones `obtenerServicio()` y `recargarPersonas()` para evitar recreaciones innecesarias de funciones en cada ciclo de render.

---

### 3.6. Estilos Modernos con Tailwind CSS v4

La integración de estilos se realiza mediante el nuevo motor de **Tailwind CSS v4** y su plugin dedicado para Vite:

1. **Configuración en [`vite.config.js`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/frontend/vite.config.js):**
   ```javascript
   import { defineConfig } from 'vite'
   import react from '@vitejs/plugin-react'
   import tailwindcss from '@tailwindcss/vite'

   export default defineConfig({
     plugins: [
       tailwindcss(), // Inyecta el compilador JIT de Tailwind v4 en la cadena de Vite
       react(),
     ],
     server: {
       port: 5173,
       proxy: {
         '/personas': {
           target: 'http://localhost:8080',
           changeOrigin: true,
         },
       },
     },
     build: {
       outDir: '../src/main/resources/static',
       emptyOutDir: true,
     },
   })
   ```
2. **Importación directa en [`index.css`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/frontend/src/index.css):**
   ```css
   @import "tailwindcss";
   ```
   En Tailwind v4 ya no se requieren archivos `tailwind.config.js` ni múltiples directivas `@tailwind base; components; utilities;`. Todo se resuelve directamente mediante la directiva `@import`.
3. **Componentes visuales:**
   * **Tarjetas:** `bg-white rounded-2xl border border-slate-200 shadow-sm`.
   * **Inputs:** `focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20`.
   * **Selector de cliente:** Botones segmentados con transiciones animadas para conmutar entre Axios y Fetch.
   * **Tabla responsiva:** Encabezados uppercase (`bg-slate-50`), celdas con tipografía monoespaciada para IDs y botones de acción (`Editar` en azul y `Borrar` en rosa/rojo).

---

## 🚀 4. Guía de Ejecución

### Requisitos Previos
* **Java:** JDK 25 LTS (o JDK 21+). Compatible de forma nativa sin configuraciones adicionales.
* **Node.js:** Versión 18+ (recomendado 20 o superior).
* **pnpm:** Gestor de paquetes rápido y eficiente.
* **MySQL:** Servidor activo (XAMPP, MySQL Workbench, etc.) con la base de datos `proyecto_jpa`.

### Pasos para Ejecutar

#### Opción 1: Desarrollo con Hot Reload (Frontend + Backend en paralelo)
Recomendado para programar o modificar componentes en React:

1. **Terminal 1 - Backend:**
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```
   *Inicia Spring Boot en `http://localhost:8080` directamente con Java 25.*

2. **Terminal 2 - Frontend:**
   ```powershell
   pnpm run dev
   # o bien:
   cd frontend
   pnpm dev
   ```
   *Inicia el dev server de Vite en `http://localhost:5173` con proxy hacia el backend.*

#### Opción 2: Producción Integrada (Spring Boot sirve el Frontend)
1. **Compilar el frontend hacia `src/main/resources/static`:**
   ```powershell
   pnpm run build
   ```
   *Vite compilará y depositará `index.html` y los bundles minificados en `src/main/resources/static/`.*

2. **Iniciar Spring Boot:**
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```
   *Ingresa directamente a `http://localhost:8080/` en tu navegador.*

---

## 🧪 5. Pruebas de API con Bruno

Para validar la API de forma independiente a la interfaz gráfica, se incluye una colección lista para usar dentro del directorio [`/bruno`](file:///c:/Users/smata/OneDrive/Documentos/Nueva carpeta/igw/Clase 15/Proyecto SB API Fetch/proyectojpa/bruno):

1. Abre la aplicación [Bruno](https://www.usebruno.com/).
2. Selecciona **Open Collection** y apunta a la carpeta `bruno` de este proyecto.
3. Ejecuta las peticiones:
   * **`Traer Personas`**: `GET http://localhost:8080/personas/traer`
   * **`Crear Persona`**: `POST http://localhost:8080/personas/crear` con body JSON `{ "nombre": "Juan Perez", "edad": 28 }`
   * **`Editar Persona`**: `PUT http://localhost:8080/personas/editar/1?id=1&nombre=Juan Modificado&edad=30`
   * **`Borrar Persona`**: `DELETE http://localhost:8080/personas/borrar/1`

---

## 📦 6. Estructura de Directorios del Repositorio

```text
proyectojpa/
├── bruno/                                  # Colección de peticiones HTTP para Bruno
│   ├── bruno.json
│   ├── Traer Personas.bru
│   ├── Crear Persona.bru
│   ├── Editar Persona.bru
│   └── Borrar Persona.bru
├── frontend/                               # Proyecto Frontend React 19 + Vite 8
│   ├── src/
│   │   ├── services/
│   │   │   └── personaService.js           # Servicios Axios y Fetch modularizados
│   │   ├── App.jsx                         # UI completa con Tailwind CSS y estado React
│   │   ├── main.jsx                        # Punto de montaje React
│   │   └── index.css                       # Directiva @import "tailwindcss";
│   ├── backup-vanilla-index.html           # Respaldo del frontend original en vanilla JS
│   ├── index.html                          # Template base de Vite
│   ├── package.json                        # Dependencias de frontend (Tailwind v4, Axios, etc.)
│   └── vite.config.js                      # Configuración de Tailwind, Proxy y Build
├── src/
│   ├── main/
│   │   ├── java/ar/edu/centro8/desarrollo/proyectojpa/
│   │   │   ├── controller/PersonaController.java   # Controlador REST (@CrossOrigin, endpoints)
│   │   │   ├── model/Persona.java                  # Entidad JPA
│   │   │   ├── repository/IPersonaRepository.java  # Repositorio Spring Data JPA
│   │   │   ├── service/                            # Lógica de servicio e interfaces
│   │   │   └── ProyectojpaApplication.java         # Clase principal Spring Boot
│   │   └── resources/
│   │       ├── application.properties              # Configuración MySQL y JPA
│   │       └── static/                             # Directorio de salida de Vite (index.html, assets)
│   └── test/
├── package.json                            # Scripts de orquestación en la raíz (pnpm dev / build)
├── pom.xml                                 # Dependencias Maven (Spring Boot 3.4.13, Java 25, MySQL)
└── README.md                               # Documentación técnica completa
```
