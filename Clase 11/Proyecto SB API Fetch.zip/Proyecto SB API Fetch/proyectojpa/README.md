# Proyecto JPA - Spring Boot con Consumo Frontend (Fetch API)

Proyecto educativo desarrollado con **Spring Boot**, **Spring Data JPA**, **Hibernate** y **MySQL**, que expone una API REST para gestionar la entidad `Persona` y ofrece un frontend estático interactivo que consume dichos endpoints mediante **JavaScript Vanilla (`fetch`)**.

---

## 🛠️ Tecnologías y Versiones

* **Lenguaje:** Java 21 (JDK 21 LTS)
* **Framework:** Spring Boot 3.4.3 (compatible con JDK 21 y Jakarta EE)
* **Persistencia:** Spring Data JPA / Hibernate
* **Base de Datos:** MySQL
* **Productividad:** Lombok (con procesador de anotaciones configurado)
* **Frontend:** HTML5, CSS3, Bootstrap 5 y JavaScript moderno (Fetch API, Async/Await)
* **API Testing:** [Bruno](https://www.usebruno.com/) (colección incluida en `/bruno`)

---

## 🚀 Requisitos Previos y Configuración

### 1. Java 21
Asegúrate de contar con el JDK 21 instalado:
```bash
java -version
```
> Si tienes múltiples versiones de Java instaladas en tu sistema, asegúrate de apuntar tu variable de entorno `JAVA_HOME` a la ruta de Java 21 (por ejemplo: `C:\Program Files\Java\jdk-21`).

### 2. Base de Datos MySQL
En tu gestor MySQL (XAMPP, WAMP, MySQL Workbench, etc.), crea la base de datos `proyecto_jpa`:
```sql
CREATE DATABASE IF NOT EXISTS proyecto_jpa;
```
Revisa las credenciales en `src/main/resources/application.properties`:
```properties
spring.application.name=proyectojpa
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/proyecto_jpa?seSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=
```

### 3. Ejecutar el Proyecto
Con el Maven Wrapper incluido:
```bash
./mvnw spring-boot:run
```
Una vez iniciado, la aplicación estará disponible en: `http://localhost:8080/`.

---

## 🌐 Consumo de la API desde `index.html` (Frontend)

El archivo [`index.html`](src/main/resources/static/index.html) ubicado en `src/main/resources/static/` es servido automáticamente por Spring Boot en la raíz (`http://localhost:8080/`).

### Arquitectura de Comunicación Frontend - Backend
```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant Navegador as Navegador (index.html)
    participant Fetch as Fetch API (JS)
    participant Backend as Spring Boot Controller (:8080)
    participant DB as Base de Datos MySQL

    Note over Usuario,DB: Carga Inicial de Datos (GET)
    Navegador->>Fetch: fetch('/personas/traer')
    Fetch->>Backend: GET /personas/traer
    Backend->>DB: persoRepo.findAll()
    DB-->>Backend: Lista de entidades Persona
    Backend-->>Fetch: JSON Array [{ id, nombre, edad }]
    Fetch-->>Navegador: Renderiza filas <tr> en la tabla

    Note over Usuario,DB: Envío de Formulario (POST)
    Usuario->>Navegador: Completa formulario y pulsa "Guardar"
    Navegador->>Fetch: Captura inputs y arma JSON
    Fetch->>Backend: POST /personas/crear (Content-Type: application/json)
    Backend->>DB: persoRepo.save(perso)
    DB-->>Backend: OK
    Backend-->>Fetch: "La persona fue creada correctamente"
```

### Explicación Detallada del Código JavaScript en `index.html`:

#### 1. Obtener y Listar Personas (`GET` con Promesas)
Al cargar la página, se ejecuta una petición `fetch` hacia el endpoint `/personas/traer`:
```javascript
// CONSULTA DE PERSONAS
fetch("http://localhost:8080/personas/traer")
    .then(response => response.json()) // 1. Parsea el cuerpo de la respuesta HTTP a un objeto/array JSON
    .then(datos => {
        // 2. Construye dinámicamente las filas de la tabla en base al array recibido
        let cad = '<tr><th>Id</th><th>Nombre</th><th>Edad</th></tr>';
        for (let persona of datos) {
            cad += `<tr>
                        <td>${persona.id}</td>
                        <td>${persona.nombre}</td>
                        <td>${persona.edad}</td>
                    </tr>`;
        }
        // 3. Inyecta el contenido HTML en la tabla
        document.getElementById("tabla1").innerHTML = cad;
    });
```
* **`fetch(url)`**: Envía una petición `GET` asíncrona.
* **`response.json()`**: Convierte el payload JSON en objetos nativos de JavaScript.
* **Template Literals (`` ` ``)**: Permite interpolar variables de cada `persona` (`id`, `nombre`, `edad`).

#### 2. Crear una Persona (`POST` con `async/await`)
Al interactuar con el formulario `#formulario-persona`:
```javascript
// NUEVA PERSONA
const formulario = document.getElementById('formulario-persona');
const resultado = document.getElementById('resultado');

formulario.addEventListener('submit', async (evento) => {
    // evento.preventDefault(); // Opcional si se desea evitar la recarga automática

    const nombre = document.getElementById('nombre').value;
    const edad = parseInt(document.getElementById('edad').value);

    // Envío del recurso mediante POST
    const respuesta = await fetch('http://localhost:8080/personas/crear', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json' // Indica al backend que enviamos un payload JSON
        },
        body: JSON.stringify({ nombre, edad }) // Serializa el objeto JavaScript a texto JSON
    });
});
```
* **`headers: { 'Content-Type': 'application/json' }`**: Crucial para que Spring Boot (`@RequestBody`) pueda deserializar correctamente los datos en la entidad Java `Persona`.
* **`JSON.stringify(...)`**: Convierte el objeto `{ nombre, edad }` a formato texto JSON: `{"nombre":"Juan","edad":25}`.

---

## 📡 Endpoints de la API REST

Todos los endpoints están expuestos en el [`PersonaController`](src/main/java/ar/edu/centro8/desarrollo/proyectojpa/controller/PersonaController.java):

| Método | Endpoint | Parámetros / Body | Descripción |
| :--- | :--- | :--- | :--- |
| `GET` | `/personas/traer` | Ninguno | Retorna la lista de todas las personas registradas |
| `POST` | `/personas/crear` | Body: `{ "nombre": "...", "edad": ... }` | Registra una nueva persona |
| `DELETE` | `/personas/borrar/{id}` | Path: `id` (Long) | Elimina la persona identificada por el ID |
| `PUT` | `/personas/editar/{id_original}` | Path: `id_original`<br>Query params: `id`, `nombre`, `edad` | Actualiza los datos de la persona |

---

## 🧪 Pruebas de API con Bruno

Se ha incluido una colección lista para usar dentro del directorio [`/bruno`](bruno/):

1. Descarga e instala [Bruno](https://www.usebruno.com/).
2. Abre Bruno y selecciona **Open Collection**.
3. Selecciona la carpeta `bruno` de este proyecto.
4. Encontrarás las siguientes solicitudes preparadas:
   - **`Traer Personas`**: `GET http://localhost:8080/personas/traer`
   - **`Crear Persona`**: `POST http://localhost:8080/personas/crear` con body JSON
   - **`Editar Persona`**: `PUT http://localhost:8080/personas/editar/1?id=1&nombre=Juan Modificado&edad=30`
   - **`Borrar Persona`**: `DELETE http://localhost:8080/personas/borrar/1`

---

## 📦 Estructura del Proyecto

```text
proyectojpa/
├── bruno/                          # Colección de pruebas para Bruno
│   ├── bruno.json                  # Configuración de colección Bruno
│   ├── Traer Personas.bru          # Request GET
│   ├── Crear Persona.bru           # Request POST
│   ├── Editar Persona.bru          # Request PUT
│   └── Borrar Persona.bru          # Request DELETE
├── src/
│   ├── main/
│   │   ├── java/ar/edu/centro8/desarrollo/proyectojpa/
│   │   │   ├── controller/PersonaController.java
│   │   │   ├── model/Persona.java
│   │   │   ├── repository/IPersonaRepository.java
│   │   │   ├── service/
│   │   │   └── ProyectojpaApplication.java
│   │   └── resources/
│   │       ├── static/
│   │       │   └── index.html      # Frontend consumidor de la API con fetch()
│   │       └── application.properties
│   └── test/
├── pom.xml                         # Configuración Maven (Java 21, Spring Boot 3.4.3, Lombok)
└── README.md                       # Documentación técnica completa
```
