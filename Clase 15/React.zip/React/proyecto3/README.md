# Proyecto 3 - Consumo de Datos con React y Vite

Este proyecto muestra cómo consumir un archivo JSON local (`/frutas.json`) y renderizar su contenido en una tabla HTML utilizando React.

---

## 📖 Explicación Detallada de `App.jsx`

El archivo [`src/App.jsx`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto3/src/App.jsx) es el componente principal de la aplicación. Su función es:
1. Mantener en memoria una lista de artículos (frutas).
2. Cargar los datos desde el archivo público `frutas.json` cuando el componente aparece en pantalla por primera vez.
3. Mostrar esos datos dinámicamente en una tabla HTML.

A continuación, se detalla el funcionamiento de cada una de sus partes y, en especial, de los **Hooks** utilizados.

---

## 🪝 ¿Qué son los Hooks de React?

Los **Hooks** son funciones especiales provistas por React que permiten a los componentes funcionales "engancharse" (*hook into*) a las características internas de React, como el estado y el ciclo de vida, sin necesidad de escribir componentes de clase.

En este componente se utilizan dos de los hooks más importantes: `useState` y `useEffect`.

---

### 1. Hook `useState`: Manejo del Estado

```javascript
const [articulos, setArticulos] = useState([])
```

#### ¿Qué hace?
`useState` declara una variable de estado dentro del componente. A diferencia de una variable común de JavaScript (como `let x = []`), el estado de React se conserva entre renderizados y, cuando cambia, **notifica a React que debe volver a dibujar (re-renderizar) la pantalla con los nuevos datos**.

#### ¿Para qué sirve?
Sirve para almacenar y controlar información dinámica que puede cambiar a lo largo del tiempo y cuyo cambio debe verse reflejado en la interfaz de usuario. En este caso, almacena la lista de artículos obtenida desde el JSON.

#### Desglose de la sintaxis:
- **`useState([])`**: Inicializa el estado con un arreglo vacío (`[]`), ya que al cargar la página todavía no se han recibido los datos del archivo JSON.
- **`articulos`**: Es la variable de solo lectura que contiene el valor actual del estado (la lista de frutas).
- **`setArticulos`**: Es la función modificadora. Es la **única** forma en que debemos actualizar el valor de `articulos`. Al invocar `setArticulos(nuevosArticulos)`, React actualiza el estado y vuelve a ejecutar el componente para mostrar los nuevos datos.

---

### 2. Hook `useEffect`: Efectos Secundarios y Ciclo de Vida

```javascript
useEffect(() => {
  fetch('/frutas.json')
    .then((response) => {
      return response.json()
    })
    .then((articulos) => {
      setArticulos(articulos)
    })
}, [])
```

#### ¿Qué hace?
`useEffect` le dice a React que el componente debe realizar una acción después de renderizarse en el DOM. Estas acciones externas se conocen como **efectos secundarios** (*side effects*).

Ejemplos comunes de efectos secundarios:
- Peticiones asíncronas a APIs o archivos (como `fetch`).
- Manipulación manual del DOM.
- Temporizadores (`setTimeout`, `setInterval`).
- Suscripción a eventos externos o sockets.

#### ¿Para qué sirve?
Sirve para sincronizar el componente con sistemas externos. En este código, se utiliza para **solicitar los datos de `/frutas.json` mediante `fetch`** en el momento adecuado, evitando bloqueos en la interfaz y llamadas innecesarias o descontroladas.

#### La importancia del arreglo de dependencias `[]`:
El segundo parámetro de `useEffect` es un arreglo de dependencias:
- **Con `[]` vacío**: La función del efecto se ejecutará **únicamente una vez**, justo después del primer renderizado (fase de montaje o *mount*).
- **¿Qué pasaría si no estuviera `[]`?**: El efecto se ejecutaría en **cada** renderizado. Esto crearía un **bucle infinito**:
  1. El componente se renderiza.
  2. `fetch` obtiene los datos.
  3. Se llama a `setArticulos(...)`.
  4. Como el estado cambió, React vuelve a renderizar el componente.
  5. Al renderizarse, vuelve a ejecutarse el efecto y repite el `fetch`, saturando la aplicación y la red.
- Por eso, el array vacío `[]` garantiza que la petición se haga **solo una vez**.

#### Flujo de la promesa `fetch`:
1. `fetch('/frutas.json')`: Realiza la petición HTTP GET al archivo alojado en la carpeta `public`.
2. `.then((response) => response.json())`: Transforma la respuesta cruda en un objeto/arreglo JavaScript usable.
3. `.then((articulos) => setArticulos(articulos))`: Guarda los datos parseados en el estado mediante `setArticulos`, disparando el segundo renderizado con la tabla llena.

---

## 🖥️ Renderizado y Método `.map()`

```jsx
return (
  <div>
    <table border="1">
      <thead>
        <tr>
          <th>Código</th>
          <th>Descripción</th>
          <th>Precio</th>
        </tr>
      </thead>
      <tbody>
        {articulos.map(art => {
          return (
            <tr key={art.codigo}>
              <td>{art.codigo}</td>
              <td>{art.descripcion}</td>
              <td>{art.precio}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  </div>
);
```

- **Estructura JSX**: Retorna una tabla HTML estándar con su encabezado (`<thead>`) y cuerpo (`<tbody>`).
- **`articulos.map(...)`**: Itera sobre cada elemento del arreglo `articulos` y devuelve una fila `<tr>` por cada fruta con sus columnas (`<td>` de código, descripción y precio).
- **Atributo `key={art.codigo}`**: React necesita un identificador único para cada elemento de una lista dinámica. Esto optimiza el rendimiento del Virtual DOM, permitiendo a React saber qué filas se agregaron, modificaron o eliminaron sin redibujar toda la lista.

---

## 📞 ¿Qué es una Función Callback?

Una **función callback** (o *"función de devolución de llamada"*) es una **función que se pasa como argumento a otra función**, para que esta última la ejecute ("la llame de vuelta") en el momento adecuado o cuando suceda un evento particular.

En JavaScript, las funciones son tratadas como valores (igual que un número, string u objeto): podés guardarlas en variables y **pasarlas como parámetros** a otras funciones.

### La analogía de la vida real 🍽️
Imaginá que vas a un restaurante lleno:
- En vez de quedarte parado en la puerta esperando sin hacer nada, le dejás tu número de teléfono al mozo.
- Le decís: *"Cuando se desocupe una mesa, llamame (*call me back*)"*.
- Vos salís a caminar o hacer otras cosas tranquilamente.
- Cuando la mesa está lista, el mozo realiza la llamada.

Eso es un **callback**: le entregás una función a otro proceso para que este la ejecute cuando corresponda.

### ¿Cómo funciona el callback en `useEffect`?
La firma de `useEffect` es:
```javascript
useEffect( funcionCallback, arregloDeDependencias )
```

En [`App.jsx`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto3/src/App.jsx):
```javascript
useEffect(() => {
  fetch('/frutas.json')...
}, [])
```
1. **La función flecha `() => { ... }` es el callback**: No la ejecutamos de inmediato (no lleva `()` al final). Le entregamos la receta a React como primer argumento.
2. **React toma el control**: React dibuja primero la pantalla inicial (el HTML) y, una vez montado el componente en el navegador, **ejecuta (llama de vuelta)** la función callback que le dejamos.

### Callbacks presentes en [`App.jsx`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto3/src/App.jsx):
El archivo está lleno de callbacks donde delegamos la ejecución:

| Dónde está en el código | ¿Quién ejecuta ese callback? | ¿Cuándo se ejecuta? |
| :--- | :--- | :--- |
| `useEffect(() => { ... }, [])` | **React** | Cuando el componente termina de montarse en el DOM. |
| `.then((response) => { ... })` | **La promesa del `fetch`** | Cuando la respuesta HTTP del archivo `/frutas.json` llega exitosamente. |
| `.then((articulos) => { ... })` | **La promesa de `.json()`** | Cuando el cuerpo de la respuesta terminó de transformarse a objeto/arreglo JavaScript. |
| `articulos.map(art => { ... })` | **El método `.map` de Array** | Se ejecuta una vez por cada elemento que exista dentro del arreglo `articulos`. |

---

## 🔄 Flujo de Ejecución Paso a Paso

1. **Montaje Inicial**:
   - `useState([])` inicializa `articulos` como `[]`.
   - React ejecuta el `return` inicial: se dibuja la tabla con los encabezados, pero el `<tbody>` queda vacío porque `articulos` no tiene elementos.
2. **Disparo de `useEffect`**:
   - Terminado el primer render en pantalla, React ejecuta el callback de `useEffect`.
   - Se inicia la petición `fetch('/frutas.json')`.
3. **Respuesta Asíncrona**:
   - Cuando la respuesta llega y se convierte a JSON, se ejecuta `setArticulos(articulos)`.
4. **Re-renderizado Automático**:
   - React detecta que el estado `articulos` cambió (ahora contiene las frutas del JSON).
   - React vuelve a ejecutar la función `App()`.
   - Esta vez, `articulos.map(...)` genera las filas con los datos de cada fruta.
   - La pantalla se actualiza mostrando la tabla completa.

---

## 📦 Carpeta `dist` y Compilación para Producción

### 1. ¿Para qué sirve la carpeta `dist`?
El nombre proviene de **"distribution"** (distribución):
- **Versión final para producción**: Contiene la aplicación totalmente compilada, empaquetada, minificada y optimizada.
- **Archivos web estándar**: Todo el código React (JSX, hooks, componentes), estilos y dependencias se transforman en HTML, CSS y JavaScript puros (dentro de `dist/` y `dist/assets/`).
- **Lista para desplegar**: Es la carpeta que se sube a servidores o plataformas de hosting (Vercel, Netlify, GitHub Pages, Firebase, Apache, Nginx, etc.). Los navegadores no pueden interpretar JSX directamente, por lo que este empaquetado previo es indispensable.

> [!NOTE]
> Esta carpeta habitualmente se ignora en el control de versiones (`.gitignore`) porque se puede regenerar automáticamente en cualquier momento.

### 2. ¿Cómo se genera?
Se genera ejecutando en la terminal el comando de compilación:

```bash
npm run build
```

En [`package.json`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto3/package.json), ese script ejecuta internamente:
```bash
vite build
```
Vite toma todos los archivos de `src/` y los estáticos de `public/`, los procesa y crea automáticamente la carpeta `dist/`.

### Comandos útiles relacionados:
- **Probar la versión de producción localmente:**
  ```bash
  npm run preview
  ```
  *(Inicia un servidor local que sirve directamente el contenido de `dist/` para verificar el funcionamiento antes de subirlo a internet).*
- **Iniciar el entorno de desarrollo:**
  ```bash
  npm run dev
  ```

---

### ⚠️ ¿Por qué los cambios o estilos se ven en desarrollo (`dev`) pero no en producción local (`dist` / `preview`)?

* **Causa (Carpeta `dist` desactualizada)**: 
  En modo desarrollo (`npm run dev`), Vite compila en memoria en tiempo real cada vez que guardas un cambio. En cambio, la carpeta `dist` **es estática y no se actualiza sola**. Si modificas estilos (como en `App.css`), agregas clases o cambias código después de haber creado `dist`, la versión de producción seguirá mostrando el código anterior.

* **¿Qué hacer si vuelve a pasar? (Solución)**:
  Debes volver a generar la carpeta ejecutando el comando de compilación antes de previsualizar:
  ```bash
  npm run build
  npm run preview
  ```

> [!TIP]
> - Si después de recompilar aún no ves los cambios, recarga el navegador con **`Ctrl + F5`** (o `Ctrl + Shift + R`) para ignorar la memoria caché.
> - Recuerda **no abrir `dist/index.html` con doble clic** desde el explorador de archivos (usando `file:///`), ya que las rutas a los estilos y archivos fallarán; usa siempre `npm run preview`.


