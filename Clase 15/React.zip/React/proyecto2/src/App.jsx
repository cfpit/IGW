import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'

function MyButton() {
  const handleClick = () => {
    window.open('https://www.google.com', '_blank');
  };

  return (
    <button onClick={handleClick}>
      Ir a Google
    </button>
  );
}

let App = function MyApp() {
  return (
    <div>
      <h1>Bienvenido a mi app</h1>
      <MyButton />
      <br /><br /><br />
      <img src="imagenes/paisaje.jpg" width="50%" />
    </div>
  );
}

export default App
