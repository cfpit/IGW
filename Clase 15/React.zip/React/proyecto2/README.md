# Proyecto 2 - Componentes, Eventos e Imágenes en React

Este proyecto es una aplicación interactiva construida con **React** y **Vite** que enseña los fundamentos esenciales del desarrollo con React:
1. Creación y composición (anidación) de componentes.
2. Manejo de eventos del usuario (`onClick`).
3. Uso de recursos estáticos e imágenes desde la carpeta `public`.

---

## 📁 Estructura del Proyecto

- [`index.html`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto2/index.html): Documento HTML principal. Contiene el contenedor `<div id="root"></div>` donde React monta toda la aplicación.
- [`src/main.jsx`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto2/src/main.jsx): Punto de entrada de JavaScript. Utiliza `createRoot` de `react-dom/client` para montar el componente principal `App` dentro del elemento `#root`.
- [`src/App.jsx`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto2/src/App.jsx): Archivo central donde se definen los componentes de la interfaz (`MyButton` y `App`).
- [`public/imagenes/paisaje.jpg`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/igw/React/proyecto2/public/imagenes/paisaje.jpg): Recurso gráfico estático servido directamente al navegador.

---

## 📖 Explicación Detallada de `src/App.jsx`

A continuación se desglosan los conceptos clave que se aplican en el código:

```jsx
import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'

function MyButton() {
  const handleClick = () => {
    window.open('https://www.google.com', '_blank');
  };

  return (
    <button onClick={handleClick}>
      Ir a Google
    </button>
  );
}

let App = function MyApp() {
  return (
    <div>
      <h1>Bienvenido a mi app</h1>
      <MyButton />
      <br /><br /><br />
      <img src="imagenes/paisaje.jpg" width="50%" />
    </div>
  );
}

export default App
```

---

### 1. Creación y Anidación de Componentes

En React, la interfaz de usuario se construye mediante **componentes reutilizables e independientes**.

#### A. El Componente Hijo: `MyButton`
```jsx
function MyButton() {
  ...
  return (
    <button onClick={handleClick}>
      Ir a Google
    </button>
  );
}
```
- Es una función de JavaScript que retorna código JSX (la sintaxis similar a HTML que usa React).
- **Regla fundamental**: El nombre del componente **debe comenzar con mayúscula** (`MyButton`). Si comenzara con minúscula (`myButton`), React lo interpretaría como una etiqueta HTML estándar desconocida en vez de un componente React.

#### B. El Componente Padre: `App`
```jsx
let App = function MyApp() {
  return (
    <div>
      <h1>Bienvenido a mi app</h1>
      <MyButton />
      <br /><br /><br />
      <img src="imagenes/paisaje.jpg" width="50%" />
    </div>
  );
}
```
- **Composición**: Dentro de `App` se incluye `<MyButton />`. React ejecuta la función `MyButton()` y renderiza su botón dentro del contenedor `<div>`.
- **Forma de declaración**: Aquí se ilustra una función expresada (`let App = function MyApp()`). Aunque es más común usar `function App() { ... }`, ambas son válidas en JavaScript.
- **Regla del elemento raíz único**: Todo componente en React debe retornar un único elemento padre (en este caso, un `<div>` que agrupa el título, el botón y la imagen).

---

### 2. Manejo de Eventos (`onClick`)

React maneja los eventos del navegador utilizando nombres en formato *camelCase* (`onClick` en lugar del `onclick` tradicional de HTML).

#### El controlador de eventos (*Event Handler*):
```javascript
const handleClick = () => {
  window.open('https://www.google.com', '_blank');
};
```
- Se declara una función flecha que realiza la acción deseada (en este caso, abre el buscador de Google en una nueva pestaña mediante `window.open`).

#### Conexión con el elemento:
```jsx
<button onClick={handleClick}>
```
> [!IMPORTANT]
> **Pasar la función vs. Ejecutar la función:**
> Se escribe `onClick={handleClick}` (se pasa la **referencia** de la función como callback).
> Si se escribiera `onClick={handleClick()}`, la función se ejecutaría de inmediato en cuanto se dibuje la pantalla, sin esperar a que el usuario haga clic.

---

### 3. Carga de Imágenes: Carpeta `public` vs `src/assets`

En este proyecto se utiliza una imagen alojada en la carpeta pública:

```jsx
<img src="imagenes/paisaje.jpg" width="50%" />
```

#### ¿Cómo funciona la carpeta `public`?
- Cualquier archivo colocado dentro de la carpeta `public/` de Vite se sirve directamente en la raíz de la URL del servidor web.
- Por eso, la ruta física `public/imagenes/paisaje.jpg` se accede desde el código como `"imagenes/paisaje.jpg"`.
- **Uso ideal:** Archivos estáticos que no necesitan ser procesados ni optimizados por el empaquetador (iconos, fuentes, PDFs o imágenes de gran tamaño).

#### Alternativa: Importar desde `src/assets`
En las primeras líneas del archivo se observan imports como:
```javascript
import heroImg from './assets/hero.png'
```
- Si quisieras mostrar esa imagen procesada por Vite, se colocaría en JSX de la siguiente manera:
  ```jsx
  <img src={heroImg} alt="Hero" />
  ```
- **Ventaja de `src/assets`:** Vite optimiza, comprime y agrega *hashes* al nombre del archivo para mejorar el almacenamiento en caché del navegador.

---

## 🔄 Flujo de Ejecución de la Aplicación

```mermaid
flowchart TD
    A["Navegador abre index.html"] --> B["Carga src/main.jsx"]
    B --> C["createRoot monta en div#root"]
    C --> D["Renderiza Componente App"]
    D --> E["Muestra título h1"]
    D --> F["Renderiza Componente MyButton"]
    F --> G["Espera clic del usuario en el botón"]
    G -->|"Usuario hace clic"| H["Ejecuta handleClick y abre Google"]
    D --> I["Carga imagen desde public/imagenes/paisaje.jpg"]
```

---

## 🚀 Cómo Ejecutar el Proyecto

1. Abrí la terminal y posicionate en la carpeta del proyecto:
   ```bash
   cd proyecto2
   ```

2. Instalá las dependencias (si aún no lo hiciste):
   ```bash
   pnpm install
   # o bien:
   npm install
   ```

3. Iniciá el servidor de desarrollo:
   ```bash
   pnpm dev
   # o bien:
   npm run dev
   ```

4. Abrí en tu navegador la dirección indicada en la terminal (usualmente `http://localhost:5173`).
