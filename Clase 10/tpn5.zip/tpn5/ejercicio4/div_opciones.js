// div_opciones.js
function mostrar (mensaje) {
	//capturo en una variable el div
	div = document.getElementById('caja');
	div.innerHTML = mensaje;
}