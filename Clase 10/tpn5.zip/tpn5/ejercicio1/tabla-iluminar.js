function iluminar (fila) 
{
	//modifico el color de fondo
	fila.style.background = 'blue';

}

function apagar (fila) 
{
	//modifico el color de fondo
	fila.style.background = '';	
}

